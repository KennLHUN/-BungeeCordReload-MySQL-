package me.kennl.listeners.bungeepluginmessages;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;

import me.kennl.BungeeCordR;
import me.kennl.database.Requests;
import net.md_5.bungee.BungeeCord;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.event.PluginMessageEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.event.EventHandler;

public class PluginMessageBungeeListener implements Listener {
	
	@EventHandler
	public void receivePluginMessage(PluginMessageEvent e) {
	
		if(e.getTag().equals("BungeeCordR")) {
	      
			final ByteArrayDataInput in = ByteStreams.newDataInput(e.getData());
			final String sub = in.readUTF();
	      
			if(sub.equals("GetPlayer")) {
	        
				String name = in.readUTF(), receiver = in.readUTF();
	        
	        final ProxiedPlayer receiverPlayer = BungeeCord.getInstance().getPlayer(receiver);
	        
	        final UUID uuid = Requests.getUUID(name);
	        
	        BungeeCordR.getInstance().logConsole("�aSearching reports for " + name + " �f(uuid: " + uuid.toString() + ") �a!");
	        
	        try {
	        
	        	final Connection connection = BungeeCordR.getInstance().getDatabase().getConnection();
	        	final PreparedStatement state = connection.prepareStatement("SELECT * FROM reports WHERE reportedUUID = ?");
	          
	        	state.setString(1, uuid.toString());
	          
	        	state.executeQuery();
	          
	        	final ResultSet result = state.getResultSet();
	          
	        	if(result.next()) {
	        		
	        		final BungeeCordR pl = BungeeCordR.getInstance();
	        		final ByteArrayDataOutput out = ByteStreams.newDataOutput();
	        		
	        		out.writeUTF("GetPlayer");
	        		out.writeInt(result.getInt("id"));
	        		out.writeUTF(result.getString("reporter"));
	        		out.writeUTF(result.getString("reported"));
	        		out.writeUTF(result.getString("reportedUUID"));
	        		out.writeUTF(result.getString("reason"));
	            
	        		final ProxiedPlayer p = pl.getProxy().getPlayer(e.getReceiver().toString());
	            
	        		p.getServer().sendData("BungeeCordR", out.toByteArray());
	          
	        	}else {
	            
	        		receiverPlayer.sendMessage(new TextComponent(BungeeCordR.getInstance().getConfig().getString("prefix", null, null) + " " + BungeeCordR.getInstance().getConfig().getString("messages.noReport", null, null)));
	        		return;
	          
	        	}
	          
	        	state.close();
	       
	        }catch (SQLException e1) {
	          e1.printStackTrace();
	        }
	        
	      }if(sub.equals("RemoveBungeeR")) {
	    	  
	    	  final String uuid = in.readUTF();
	        
	    	  BungeeCordR.getInstance().logConsole("�cDelete report for UUID: " + uuid);
	       
	    	  try {
	          
	    		  final PreparedStatement q = BungeeCordR.getInstance().getDatabase().getConnection().prepareStatement("DELETE FROM `reports` WHERE reportedUUID = ?");
	    		  q.setString(1, uuid);
	    		  q.execute();
	    		  q.close();
	          
	    		  final BungeeCordR pl = BungeeCordR.getInstance();
	    		  final ByteArrayDataOutput out = ByteStreams.newDataOutput();
	    		  out.writeUTF("RemoveBungeeReport");
	    		  out.writeBoolean(true);
	          
	    		  final ProxiedPlayer p = pl.getProxy().getPlayer(e.getReceiver().toString());
	          
	    		  p.getServer().sendData("BungeeCordR", out.toByteArray());
	          
	    		  q.close();
	    		  
	    	  }catch(SQLException e2) {
	    		  e2.printStackTrace();
	    	  }
	    	  
	      }else if(sub.equals("getMySQL")) {
	    	  
	    	  final BungeeCordR pl = BungeeCordR.getInstance();
	    	  final ByteArrayDataOutput out = ByteStreams.newDataOutput();
	    	  out.writeUTF("getMySQL");
	    	  out.writeBoolean(BungeeCordR.getInstance().getConfig().isMySQL());
	        
	    	  final ProxiedPlayer p = pl.getProxy().getPlayer(e.getReceiver().toString());
	        
	    	  p.getServer().sendData("BungeeCordR", out.toByteArray());
	      }
	      
		}
		
	}
}
