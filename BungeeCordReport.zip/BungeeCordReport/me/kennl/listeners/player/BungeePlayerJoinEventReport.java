package me.kennl.listeners.player;

import me.kennl.BungeeCordR;
import me.kennl.utils.CheckVersion;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.event.PlayerDisconnectEvent;
import net.md_5.bungee.api.event.PostLoginEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.event.EventHandler;

public class BungeePlayerJoinEventReport implements Listener {
	
	@EventHandler
	public void onJoin(PostLoginEvent e) {
		
		final ProxiedPlayer player = e.getPlayer();
		 
		if(player.hasPermission("bungeecordreports.admin") || player.hasPermission("bungeecordreports.*")) {
			
			if(CheckVersion.hasUpdate()) {
				
				player.sendMessage(new TextComponent("�8�m---------------�cBungeeCordReports Update�8�m---------------"));
				player.sendMessage(new TextComponent(""));
				player.sendMessage(new TextComponent(" �7New version available "));
				player.sendMessage(new TextComponent("�f�lLink Update:"));
				player.sendMessage(new TextComponent(""));				
			    player.sendMessage(new TextComponent("�r�7 https://www.spigotmc.org/resources/bungeereports-mysql-english-version.64037/"));
				player.sendMessage(new TextComponent(""));
				player.sendMessage(new TextComponent("�8�m---------------------------------------------------"));
				
			}
			
		}
		
		if(player.hasPermission("bungeecordreports.admin") || player.hasPermission("bungeecordreports.players") || player.hasPermission("bungeecordreports.*"))
			
			if(!BungeeCordR.getInstance().getMods().contains(player))
				
				BungeeCordR.getInstance().getMods().add(player);
		
	}
	
	@EventHandler
	public void onQuit(PlayerDisconnectEvent e) {
		
		final ProxiedPlayer player = e.getPlayer();
		
		if(BungeeCordR.getInstance().getMods().contains(player))
			
			BungeeCordR.getInstance().getMods().remove(player);
		
	}

}
