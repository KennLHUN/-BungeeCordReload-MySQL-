package me.kennl.listeners;

import me.kennl.listeners.player.BungeePlayerJoinEventReport;
import me.kennl.listeners.bungeepluginmessages.PluginMessageBungeeListener;
import net.md_5.bungee.api.plugin.Plugin;

public class ListenerManagerBungee {
	
	public ListenerManagerBungee(final Plugin plugin) {
		
		plugin.getProxy().getPluginManager().registerListener(plugin, new BungeePlayerJoinEventReport());
		plugin.getProxy().getPluginManager().registerListener(plugin, new PluginMessageBungeeListener());
		
	}

}