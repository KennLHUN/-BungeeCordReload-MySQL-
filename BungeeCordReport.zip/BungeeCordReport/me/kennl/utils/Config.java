package me.kennl.utils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.CopyOption;
import java.nio.file.Files;

import me.kennl.BungeeCordR;
import net.md_5.bungee.config.Configuration;
import net.md_5.bungee.config.ConfigurationProvider;
import net.md_5.bungee.config.YamlConfiguration;

public class Config {
	
	
	private boolean clickEvent, useUUID, mySQL;
	
	private BungeeCordR main;
	private File file;
	private Configuration configuration;
	
	
	public Config() {
		
		this.main = BungeeCordR.getInstance();
		createFile();			
		this.clickEvent = getConfiguration().getBoolean("Actions.MessageClickEvent");
		this.useUUID = getConfiguration().getBoolean("UUIDUse");
		this.mySQL = getConfiguration().getBoolean("MySql.Enable");
		
	}
	
	private void createFile() {
		
		if(!this.main.getDataFolder().exists())
			this.main.getDataFolder().mkdirs();
		
		this.file = new File(this.main.getDataFolder(), "config.yml");
		
		if(!this.file.exists()) {
			
			try (final InputStream source = BungeeCordR.class.getResourceAsStream("/config.yml")){
				
				Files.copy(source, this.file.toPath(), new CopyOption[0]);
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
		
		try {
			this.configuration = ConfigurationProvider.getProvider(YamlConfiguration.class).load(this.file);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void reloadConfig() {
		
		try {
			this.configuration = ConfigurationProvider.getProvider(YamlConfiguration.class).load(this.file);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public String getString(String path, String[] keys, String[] values) {
		
		String text = getConfiguration().getString(path);
		
		if((keys == null && values == null) || keys.length == values.length) {
			
			text = text.replace("&", "�");
			
			if(keys != null) {
			
				for(int i = 0; i < keys.length; i++) {
					
					final String key = keys[i];
					final String value = values[i];
					
					if(text.contains(key))
						
						text = text.replace(key, value);
					
				}
				
			}
			
		}
		
		return text;
		
	}
	
	
	public Configuration getConfiguration() {
		return configuration;
	}
	
	public boolean isMySQL() {
		return mySQL;
	}
	
	public boolean isClickEvent() {
		return clickEvent;
	}
	
	public boolean isUseUUID() {
		return useUUID;
	}

}
