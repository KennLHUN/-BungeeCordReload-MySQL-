package me.kennl.utils;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import me.kennl.BungeeCordR;
import net.md_5.bungee.api.config.ServerInfo;

public class ReportData {
	
	private BungeeCordR main;
	
	private int id;
	private String reporter, reported, reason;
	private UUID uuid;
	private ServerInfo info;
	
	public ReportData(int id, String reporter, String reported, String reason, UUID uuid, ServerInfo info) {
		
		this.setId(id);
		this.setReported(reported);
		this.setReporter(reporter);
		this.setReason(reason);
		this.setUuid(uuid);
		this.setInfo(info);
		
		this.main = BungeeCordR.getInstance();
		
		registerInDatabase();
		
	}
	
	private void registerInDatabase() {
		
		try {
			
			if(!this.main.getDatabase().getConnection().isClosed()) {
				
				PreparedStatement reports, reasons;
				
				if(this.main.getConfig().isUseUUID()) {
					
					reports = this.main.getDatabase().getConnection().prepareStatement("SELECT * FROM reports WHERE reportedUUID = ?");
					reports.setString(1, this.getUuid().toString());
					
					reasons = this.main.getDatabase().getConnection().prepareStatement("SELECT * FROM reasons WHERE uuid = ?");
					reasons.setString(1, this.getUuid().toString());
					
				}else {
					
					reports = this.main.getDatabase().getConnection().prepareStatement("SELECT * FROM reports WHERE reported = ?");
					reports.setString(1, this.getReported());
					
					reasons = this.main.getDatabase().getConnection().prepareStatement("SELECT * FROM reasons WHERE name = ?");
					reasons.setString(1, this.getReported());
					
				}
				
				reports.executeQuery();
				
				final ResultSet reportsResult = reports.getResultSet();
				
				if(reportsResult.next()) {
					
					this.setId(reportsResult.getInt("id"));
					
					if(this.main.getReasons().containsKey(this.getId())) {
						
						this.main.getReasons().get(this.getId()).add(this.getReason());
						
					}else {
						
						reasons.executeQuery();
						
						final List<String> list = new ArrayList<>();
						final ResultSet reasonsResult = reasons.getResultSet();
						
						if(reasonsResult.next())
							
							while(reasonsResult.next())
								
								list.add(reasonsResult.getString("reason"));
							
						
						list.add(this.getReason());
						
						this.main.getReasons().put(this.getId(), list);
						
						addInDatabase(true);
						
					}
					
				}else {
					
					addInDatabase(false);
					
				}
				
			}else {
				
				this.main.logConsole("�4Error ! The connection is closed !");
				return;
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	  
	private void addInDatabase(final boolean registerReasonOnly) throws SQLException {
		
		if(!registerReasonOnly) {
		
		    final PreparedStatement state = this.main.getDatabase().getConnection().prepareStatement("INSERT INTO reports (reporter, reported, reportedUUID) VALUES (?, ?, ?)", 1);
		    
		    state.setString(1, this.getReporter());
		    state.setString(2, this.getReported());
		    state.setString(3, this.getUuid().toString());
		    
		    int row = state.executeUpdate();
		    
		    final ResultSet resultSet = state.getGeneratedKeys();
		    
		    if((row > 0) && (resultSet.next())) {
		      
		    	int id = resultSet.getInt(1);
		      
		    	this.setId(id);
	
		    }
		    
		    state.close();
	    
		}
	    
	    final PreparedStatement reasonState = this.main.getDatabase().getConnection().prepareStatement("INSERT INTO reasons (uuid, name, reason) VALUES (?,?,?)");
	    
	    reasonState.setString(1, this.getUuid().toString());
	    reasonState.setString(2, this.getReported());
	    reasonState.setString(3, this.getReason());
		    
	    reasonState.executeUpdate();
	    
	    reasonState.close();
	    
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getReporter() {
		return reporter;
	}

	public void setReporter(String reporter) {
		this.reporter = reporter;
	}

	public String getReported() {
		return reported;
	}

	public void setReported(String reported) {
		this.reported = reported;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public UUID getUuid() {
		return uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public ServerInfo getInfo() {
		return info;
	}

	public void setInfo(ServerInfo info) {
		this.info = info;
	}

}
