package me.kennl.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

import me.kennl.BungeeCordR;

public class Requests {
	
	public static void createTables() {
		
		try {
			
			final Connection connection = BungeeCordR.getInstance().getDatabase().getConnection();
			connection.prepareStatement("CREATE TABLE IF NOT EXISTS reports (id int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT, reporter varchar(255) NOT NULL, reported varchar(255) NOT NULL, reportedUUID varchar(255) NOT NULL)").executeUpdate();
			connection.prepareStatement("CREATE TABLE IF NOT EXISTS userslist (name varchar(255) NOT NULL, uuid varchar(255) NOT NULL)").executeUpdate();
			connection.prepareStatement("CREATE TABLE IF NOT EXISTS reasons (uuid varchar(255) NOT NULL, name varchar(25) NOT NULL, reason varchar(255) NOT NULL)").executeUpdate();
			 
		} catch (SQLException e) {
			
			BungeeCordR.getInstance().logConsole("�cError while creating the database tables.");
			
			e.printStackTrace();
		}
		
	}
	
	public static UUID getUUID(String name) {
		
		try (final Connection connection = BungeeCordR.getInstance().getDatabase().getConnection()) {
			
			final PreparedStatement preparedStatement = connection.prepareStatement("SELECT reportedUUID FROM userslist WHERE reported = ?");
			
			preparedStatement.setString(1, name);
			preparedStatement.executeQuery();
			
			final ResultSet resultSet = preparedStatement.getResultSet();
			
			if(resultSet.next())
				
				return UUID.fromString(resultSet.getString("reportedUUID"));
			
			preparedStatement.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
		
	}

}
