package me.kennl.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;

import me.kennl.BungeeCordR;
import net.md_5.bungee.BungeeCord;
import net.md_5.bungee.api.scheduler.ScheduledTask;

public class Database {
	
	private Connection connection;
	
	private String url = "jdbc:mysql://", host, user, password, database;
	
	private ScheduledTask task;
	private int timer = 1600;
	
	public Database(String host, String user, String password, String database) {
		
		this.host = host;
		this.user = user;
		this.password = password;
		this.database = database;
		
		connect();
		
		BungeeCord.getInstance().getScheduler().runAsync(BungeeCordR.getInstance(), () ->{
			
			Requests.createTables();	
			
		});
		
	}
	
	public void connect() {
		
		if(this.getConnection() == null) {
			
			try {
				this.connection = DriverManager.getConnection(this.url + this.host + "/" + this.database, this.user, this.password);
			} catch (SQLException e) {
				BungeeCordR.getInstance().logConsole("�cError while connecting to the database.");
				e.printStackTrace();
			}
						
			if(this.task == null) {
			
				this.task = BungeeCord.getInstance().getScheduler().schedule(BungeeCordR.getInstance(), new Runnable() {
					
					@Override
					public void run() {
						
						if(Database.this.timer == 0) {
							
							BungeeCordR.getInstance().getDatabase().disconnect(false);
							BungeeCordR.getInstance().getDatabase().connect();
							
							Database.this.timer = 1600;
							
						}
						
						timer--;
						
					}
				}, 0L, 1L, TimeUnit.SECONDS);
				
			}
			
		}
		
	}
	
	public void disconnect(final boolean stop) {
		
		if(this.connection != null) {
			
			if(stop)
				
				this.task.cancel();
			
			try {
				this.connection.close();
			} catch (SQLException e) {
				BungeeCordR.getInstance().logConsole("�cError while disconnecting the database.");
				e.printStackTrace();
			}
			
		}
		
	}
	
	
	public String getDatabase() {
		return database;
	}
	
	public String getUrl() {
		return url;
	}
	
	public Connection getConnection() {
		return connection;
	}
	
	public String getHost() {
		return host;
	}
	
	public String getPassword() {
		return password;
	}
	
	public String getUser() {
		return user;
	}

}
