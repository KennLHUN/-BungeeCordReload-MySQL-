package me.kennl.commands;

import me.kennl.commands.admin.BungeeCordRCommand;
import me.kennl.commands.admin.ServerTeleport;
import me.kennl.commands.player.BungeeReportCommand;
import net.md_5.bungee.api.plugin.Plugin;

public class CommandsManager {
	
	public CommandsManager(final Plugin plugin) {
		
		plugin.getProxy().getPluginManager().registerCommand(plugin, new BungeeCordRCommand());
		plugin.getProxy().getPluginManager().registerCommand(plugin, new BungeeReportCommand());
		plugin.getProxy().getPluginManager().registerCommand(plugin, new ServerTeleport());
		
	}

}