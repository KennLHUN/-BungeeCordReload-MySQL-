package me.kennl.commands.admin;

import me.kennl.BungeeCordR;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.plugin.Command;

public class BungeeCordRCommand extends Command {
	
	private BungeeCordR main;

	public BungeeCordRCommand() {
		
		super("reportbungee");
		
		this.main = BungeeCordR.getInstance();
	}
	
	@Override
	public void execute(CommandSender sender, String[] args) {
		
		if(sender instanceof ProxiedPlayer) {
			
			final ProxiedPlayer player = (ProxiedPlayer) sender;
			
			if(player.hasPermission("bungeecordreports.admin") || player.hasPermission("bungeecordreports.*")) {
				
				if(args.length == 0) {
					
					showHelp(player);
					return;
					
				}else {
					
					if(args[0].equalsIgnoreCase("reload")) {
						
						if(args.length == 1 || args[1] == null) {
							
							if(this.main.getConfig().isMySQL()) {
								
								player.sendMessage(new TextComponent("�aReloading the database access."));
								player.sendMessage(new TextComponent("�cWarning ! While the database is reloading, the reports will not be save!"));
								
								this.main.getDatabase().disconnect(false);
								this.main.getDatabase().connect();
								
								player.sendMessage(new TextComponent("�aThe database acces has been successfuly reloaded!"));
								
							}else
								
								player.sendMessage(new TextComponent("�cThe database option is disabled."));
							
							player.sendMessage(new TextComponent("�aReloading the config file..."));
							this.main.getConfig().reloadConfig();
							player.sendMessage(new TextComponent("�aThe config has been successfuly reloaded!"));
							
						}else if(args.length > 1) {
							
							if(args[1].equalsIgnoreCase("config")) {
								
								player.sendMessage(new TextComponent("�aReloading the config file..."));
								this.main.getConfig().reloadConfig();
								player.sendMessage(new TextComponent("�aThe config has been successfuly reloaded!"));
								
							}else if(args[1].equalsIgnoreCase("database")) {
								
								if(this.main.getConfig().isMySQL()) {
									
									player.sendMessage(new TextComponent("�aReloading the database access."));
									player.sendMessage(new TextComponent("�cWarning! While the database is reloading, the reports will not be save!"));
									
									this.main.getDatabase().disconnect(false);
									this.main.getDatabase().connect();
									
									player.sendMessage(new TextComponent("�aThe database acces has been successfuly reloaded!"));
									
								}else
									
									player.sendMessage(new TextComponent("�cThe database option is disabled."));
								
							}
							
						}
						
					}else {
						
						showHelp(player);
						return;
						
					}
					
				}
				
			}else {
				
				this.main.getConfig().getString("messages.noPerm", null, null);
				return;
				
			}
		
		}
		
	}
	
	private void showHelp(ProxiedPlayer player) {
		
		player.sendMessage(new TextComponent("�8�m-----------�f�nPlugin By:�r�8�m-----------"));
	    player.sendMessage(new TextComponent(""));
	    player.sendMessage(new TextComponent("�cBungeeCordReports v" + this.main.getDescription().getVersion()));
	    player.sendMessage(new TextComponent(""));
	    player.sendMessage(new TextComponent("�4�l�nCommands:�r "));
	    player.sendMessage(new TextComponent(""));	    
	    player.sendMessage(new TextComponent("�c/reportbungee �freload (database/config) �8-> �7Reload the config or the database"));
	    player.sendMessage(new TextComponent(""));
	    player.sendMessage(new TextComponent("�c/rbtp �f<player> �8-> �7Teleport you on the same server than a player."));
	    player.sendMessage(new TextComponent(""));
	    player.sendMessage(new TextComponent("�c/report �f<player> �8-> �7Teleport you on the same server than a player."));	    
	    player.sendMessage(new TextComponent(""));
	    player.sendMessage(new TextComponent("�8�m-------------�r�fKennL�r�8�m--------------"));
	    
	}

}