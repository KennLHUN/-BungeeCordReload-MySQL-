package me.kennl.commands.admin;

import me.kennl.BungeeCordR;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.config.ServerInfo;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.plugin.Command;

public class ServerTeleport extends Command {
	
	private BungeeCordR main;
	
	public ServerTeleport() {
		super("rbtp");
		this.main = BungeeCordR.getInstance();
	}

	@Override
	public void execute(CommandSender sender, String[] args) { 
		
		if(sender instanceof ProxiedPlayer) {
			
			final ProxiedPlayer player = (ProxiedPlayer) sender;
			
			if(player.hasPermission("bungeecordreports.players") || player.hasPermission("bungeecordreports.admin") || player.hasPermission("bungeecordreports.*")) {
				
				if(args.length == 0) {
					
					showHelp(player);
					return;
					
				}else {
					
					final String name = args[0];
					final ProxiedPlayer target = ProxyServer.getInstance().getPlayer(name);
					
					if(target != null) {
						
						final ServerInfo info = target.getServer().getInfo();
						
						player.sendMessage(new TextComponent(this.main.getConfig().getString("Actions.Message", new String[] {"%target%", "%server%"}, new String[] {name, info.getName()})));
						player.connect(info);
						player.sendMessage(new TextComponent(this.main.getConfig().getString("Actions.successfulTeleportation", new String[] {"%player%", "%target%", "%server%"}, new String[] {player.getName(), target.getName(), info.getName()})));
						
					}else {
						
						player.sendMessage(new TextComponent(this.main.getConfig().getString("messages.notarget", null, null)));
						return;
						
					}
					
				}
				
			}else {
				
				this.main.getConfig().getString("messages.noPerm", null, null);
				return;
				
			}
			
		}
		
	}
	
	private void showHelp(ProxiedPlayer player) {
		
		player.sendMessage(new TextComponent("�8�m-----------�f�nPlugin By:�r�8�m-----------"));
	    player.sendMessage(new TextComponent(""));
	    player.sendMessage(new TextComponent("�cBungeeCordReports v" + this.main.getDescription().getVersion()));
	    player.sendMessage(new TextComponent(""));
	    player.sendMessage(new TextComponent("�4�l�nCommands:�r "));
	    player.sendMessage(new TextComponent(""));	    
	    player.sendMessage(new TextComponent("�c/reportbungee �freload (database/config) �8-> �7Reload the config or the database"));
	    player.sendMessage(new TextComponent(""));
	    player.sendMessage(new TextComponent("�c/rbtp �f<player> �8-> �7Teleport you on the same server than a player."));
	    player.sendMessage(new TextComponent(""));
	    player.sendMessage(new TextComponent("�c/report �f<player> �8-> �7Player reporting if cheat."));	    
	    player.sendMessage(new TextComponent(""));
	    player.sendMessage(new TextComponent("�8�m-------------�r�fKennL�r�8�m--------------"));
	    
	}
}
