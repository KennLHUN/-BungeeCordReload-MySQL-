package me.kennl.commands.player;

import java.util.HashMap;
import java.util.Map;

import me.kennl.BungeeCordR;
import me.kennl.utils.ReportData;
import net.md_5.bungee.BungeeCord;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.plugin.Command;

public class BungeeReportCommand extends Command {

	private Map<String, Long> cooldown = new HashMap<>();
	
	private int seconds;
	private long timeleft;
	
	private BungeeCordR main = BungeeCordR.getInstance();
	private String prefix = this.main.getConfig().getString("prefix", null, null);
	  
	public BungeeReportCommand() {
		super("report");
	}
	  
	public void execute(CommandSender sender, String[] args) {
	  
		if((sender instanceof ProxiedPlayer)) {
	      
			final ProxiedPlayer p = (ProxiedPlayer)sender;
	  
			if ((p.hasPermission("bungeecordreports.command.report")) || (p.hasPermission("bungeecordreports.*"))) {
	       
				if (this.cooldown.containsKey(p.getName())) {
	         
					this.seconds = this.main.getConfig().getConfiguration().getInt("cooldown");
	          
	      
					this.timeleft = (((Long)this.cooldown.get(p.getName())).longValue() / 1000L + this.seconds - System.currentTimeMillis() / 1000L);
	          
					if (this.timeleft > 0L) {
	            
						p.sendMessage(new TextComponent(this.prefix + " " +this.main.getConfig().getString("messages.cooldown", new String[] {"%timeleft%"}, new String[] {this.timeleft + ""})));
						return;
	         
					}
					}
	        
				if((args.length == 0) || (args.length == 1)) {
	         
					p.sendMessage(new TextComponent(this.prefix + " " + this.main.getConfig().getString("messages.usage", null, null)));
	          
					return;
	        
				}
	       
				String name = args[0], reason = "";
				final ProxiedPlayer target = BungeeCord.getInstance().getPlayer(name);
				
				if(target != null) {
	          
					for (int i = 1; i < args.length; i++) {
	           
						if (i > 1) {
	             
							reason = reason + " " + args[i];
	            
						} else {
	             
							reason = args[i];
	           
						}
	          
					}
	          
					if(this.main.getConfig().isMySQL())
	          
						new ReportData(0, p.getName(), name, reason, target.getUniqueId(), target.getServer().getInfo());
	         
					p.sendMessage(new TextComponent(this.prefix + " " + this.main.getConfig().getString("messages.reportermessage", null, null)));
	         
					for(ProxiedPlayer mods : this.main.getMods()) {
	          
						if(this.main.getConfig().isClickEvent()) {
	              
							final TextComponent tp = new TextComponent(this.main.getConfig().getString("Actions.ClickEventMessage", null, null));
	              
							tp.setClickEvent(new ClickEvent(ClickEvent.Action.SUGGEST_COMMAND, "/rbtp " + target.getName()));
							tp.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder(this.main.getConfig().getString("Actions.HoverMessage", null, null)).create()));
	              
							mods.sendMessage(new TextComponent(this.prefix + " " + this.main.getConfig().getString("messages.message", new String[] {"%reporter%", "%victim%", "%reason%"}, new String[] {p.getName(), target.getName(), reason}).replace("%victim%", target.getName())));
						
						}else {
	             
							mods.sendMessage(new TextComponent(this.prefix + " " + this.main.getConfig().getString("messages.message", new String[] {"%reporter%", "%victim%", "%reason%"}, new String[] {p.getName(), target.getName(), reason}).replace("%victim%", target.getName())));	          
						
						}
	          
					}
	        
					this.cooldown.put(p.getName(), Long.valueOf(System.currentTimeMillis()));
	       
				}else {
	          
					p.sendMessage(new TextComponent(this.prefix + " " + this.main.getConfig().getString("messages.notarget", null, null)));
	        
				}
	      
			}else {
	        
				p.sendMessage(new TextComponent(this.main.getConfig().getString("messages.nopermission", null, null)));
	     
			}
	    
		}else {
	     
			sender.sendMessage(new TextComponent("�cYou have no access to this command!"));
	     
			return;
	   
		}
	 
	}
	
}